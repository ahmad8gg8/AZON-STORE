(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var csrf = ($('meta[name="csrf-token"]') || {}).content || '';
  function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : t; return d.innerHTML; }
  function post(url, data) {
    return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf, Accept: 'application/json' }, body: JSON.stringify(data || {}) })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, data: j }; }); });
  }

  /* sidebar */
  var side = $('#side'), ov = $('#overlay');
  var bg = $('#burger'); if (bg) bg.addEventListener('click', function () { side.classList.toggle('on'); });

  /* generic overlay helpers */
  function closeAll() {
    $$('.modal.on,.sheet.on,.palette.on').forEach(function (e) { e.classList.remove('on'); });
    ov.classList.remove('on'); side && side.classList.remove('on');
  }
  ov.addEventListener('click', closeAll);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeAll(); });
  function open(el) { el.classList.add('on'); ov.classList.add('on'); }

  /* confirm dialogs */
  document.addEventListener('submit', function (e) {
    var f = e.target, m = f.getAttribute('data-confirm');
    if (m && !confirm(m)) e.preventDefault();
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-confirm]:not(form)');
    if (b && !confirm(b.getAttribute('data-confirm'))) { e.preventDefault(); e.stopPropagation(); }
  }, true);

  /* copy buttons */
  document.addEventListener('click', function (e) {
    var c = e.target.closest('[data-copy]');
    if (!c) return;
    try { navigator.clipboard.writeText(c.getAttribute('data-copy')); } catch (er) {}
    var t = c.querySelector('span'); var old = c.innerHTML;
    c.classList.add('copied'); if (!t) { c.textContent = 'تم ✓'; setTimeout(function () { c.innerHTML = old; }, 1200); }
  });

  /* reveal code */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-reveal]');
    if (!b) return;
    b.disabled = true;
    post('/admin/api/codes/' + b.getAttribute('data-reveal') + '/reveal').then(function (r) {
      b.disabled = false;
      if (!r.ok) return alert(r.data.error || 'تعذّر الكشف');
      var tgt = $(b.getAttribute('data-target'));
      if (tgt) { tgt.textContent = r.data.code; tgt.classList.add('revealed'); }
      b.hidden = true;
    });
  });

  /* ---------- command palette ---------- */
  var pal = $('#palette'), pin = $('#palInput'), plist = $('#palList');
  var PAGES = JSON.parse((pal && pal.getAttribute('data-pages')) || '[]');
  var items = [], sel = 0, timer;
  function render(list) {
    items = list; sel = 0;
    plist.innerHTML = list.map(function (it, i) {
      if (it.group) return '<li class="grp">' + esc(it.group) + '</li>';
      return '<li><a href="' + esc(it.href) + '" data-i="' + i + '" class="' + (i === sel ? 'sel' : '') + '">' + esc(it.label) + (it.sub ? ' <span class="muted sm">' + esc(it.sub) + '</span>' : '') + '</a></li>';
    }).join('') || '<li class="empty">ما في نتائج</li>';
    var first = plist.querySelector('a'); if (first) first.classList.add('sel');
  }
  function pages(q) {
    var out = PAGES.filter(function (p) { return !q || p.label.indexOf(q) > -1; });
    return out.length ? [{ group: 'الصفحات' }].concat(out) : [];
  }
  function openPal() { open(pal); pin.value = ''; render(pages('')); setTimeout(function () { pin.focus(); }, 30); }
  if (pal) {
    $$('[data-palette]').forEach(function (b) { b.addEventListener('click', openPal); });
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPal(); }
    });
    pin.addEventListener('input', function () {
      var q = pin.value.trim(); clearTimeout(timer);
      if (!q) return render(pages(''));
      timer = setTimeout(function () {
        fetch('/admin/api/search?q=' + encodeURIComponent(q)).then(function (r) { return r.json(); }).then(function (d) {
          var list = pages(q);
          if (d.orders.length) list.push({ group: 'الطلبات' }), d.orders.forEach(function (o) { list.push({ label: 'طلب #' + o.id, sub: o.username + ' · $' + o.total.toFixed(2), href: '/admin/orders/' + o.id }); });
          if (d.products.length) list.push({ group: 'المنتجات' }), d.products.forEach(function (p) { list.push({ label: p.name, href: '/admin/products/' + p.id + '/edit' }); });
          if (d.customers.length) list.push({ group: 'العملاء' }), d.customers.forEach(function (c) { list.push({ label: c.username, href: '/admin/customers/' + c.id }); });
          render(list);
        });
      }, 180);
    });
    pin.addEventListener('keydown', function (e) {
      var links = $$('a', plist); if (!links.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault(); links[sel] && links[sel].classList.remove('sel');
        sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + links.length) % links.length;
        links[sel].classList.add('sel'); links[sel].scrollIntoView({ block: 'nearest' });
      } else if (e.key === 'Enter') { e.preventDefault(); location.href = links[sel].getAttribute('href'); }
    });
  }

  /* ---------- image picker (upload / library / paste) ---------- */
  var activePicker = null, libModal = $('#mediaModal');
  function setPicker(p, url) {
    $('.pk-val', p).value = url || '';
    var pv = $('.pv', p);
    pv.style.backgroundImage = url ? 'url("' + url + '")' : '';
    pv.innerHTML = url ? '' : '<span class="sm">لا صورة</span>';
    $('.pk-clear', p).hidden = !url;
  }
  function upload(p, file) {
    var errEl = $('.err', p), bar = $('.bar', p), fill = $('.bar i', p);
    errEl.textContent = '';
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) { errEl.textContent = 'الصورة أكبر من 20MB — صغّرها وجرّب مرة ثانية.'; return; }
    var fd = new FormData(); fd.append('kind', p.getAttribute('data-kind') || 'default'); fd.append('file', file);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/admin/media/upload');
    xhr.setRequestHeader('X-CSRF-Token', csrf);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.upload.onprogress = function (ev) { if (ev.lengthComputable) fill.style.width = Math.round(ev.loaded / ev.total * 100) + '%'; };
    bar.hidden = false; fill.style.width = '2%';
    xhr.onload = function () {
      var j = {}; try { j = JSON.parse(xhr.responseText); } catch (e) {}
      fill.style.width = '100%'; setTimeout(function () { bar.hidden = true; fill.style.width = '0'; }, 500);
      if (xhr.status === 200 && j.url) setPicker(p, j.url);
      else errEl.textContent = j.error || ('فشل الرفع (' + xhr.status + ')');
    };
    xhr.onerror = function () { bar.hidden = true; errEl.textContent = 'انقطع الاتصال أثناء الرفع.'; };
    xhr.send(fd);
  }
  $$('.picker').forEach(function (p) {
    var fi = $('input[type=file]', p);
    $('.pk-pick', p).addEventListener('click', function () { fi.click(); });
    fi.addEventListener('change', function () { upload(p, fi.files[0]); fi.value = ''; });
    $('.pk-clear', p).addEventListener('click', function () { setPicker(p, ''); });
    $('.pk-lib', p).addEventListener('click', function () { activePicker = p; openLib(); });
    ['dragenter', 'dragover'].forEach(function (ev) { p.addEventListener(ev, function (e) { e.preventDefault(); p.classList.add('drag'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { p.addEventListener(ev, function (e) { e.preventDefault(); p.classList.remove('drag'); }); });
    p.addEventListener('drop', function (e) { if (e.dataTransfer.files[0]) upload(p, e.dataTransfer.files[0]); });
    p.addEventListener('mouseenter', function () { activePicker = p; });
    setPicker(p, $('.pk-val', p).value);
  });
  document.addEventListener('paste', function (e) {
    if (!activePicker || !e.clipboardData) return;
    var f = Array.prototype.slice.call(e.clipboardData.files || []).filter(function (x) { return /^image\//.test(x.type); })[0];
    if (f) { e.preventDefault(); upload(activePicker, f); }
  });
  function openLib() {
    if (!libModal) return;
    open(libModal);
    var g = $('#mediaGrid'); g.innerHTML = '<p class="empty">جاري التحميل…</p>';
    fetch('/admin/media/list').then(function (r) { return r.json(); }).then(function (rows) {
      g.innerHTML = rows.length ? rows.map(function (m) {
        return '<div class="mi" data-url="' + esc(m.url) + '" style="background-image:url(\'' + esc(m.url) + '\')"><small>' + Math.round(m.size / 1024) + 'KB</small></div>';
      }).join('') : '<p class="empty">المكتبة فاضية — ارفع أول صورة.</p>';
    });
  }
  if (libModal) libModal.addEventListener('click', function (e) {
    var mi = e.target.closest('.mi');
    if (mi && activePicker) { setPicker(activePicker, mi.getAttribute('data-url')); closeAll(); }
  });
  document.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) closeAll(); });

  /* ---------- order side sheet ---------- */
  var sheet = $('#sheet');
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-sheet]');
    if (!a || !sheet) return;
    if (e.target.closest('a,button,form,select') && !e.target.closest('[data-sheet]').matches('tr')) { if (e.target.closest('a[href]:not([data-sheet])')) return; }
    e.preventDefault();
    sheet.innerHTML = '<p class="empty">جاري التحميل…</p>'; open(sheet);
    fetch(a.getAttribute('data-sheet') + '?partial=1').then(function (r) { return r.text(); }).then(function (h) { sheet.innerHTML = h; });
  });

  /* ---------- product quick edit ---------- */
  document.addEventListener('change', function (e) {
    var t = e.target;
    var id = t.getAttribute('data-quick-id'); if (!id) return;
    var field = t.getAttribute('data-quick'); var val = t.type === 'checkbox' ? t.checked : t.value;
    post('/admin/api/products/' + id + '/quick', { field: field, value: val }).then(function (r) {
      t.style.outline = r.ok ? '2px solid #2ee6a6' : '2px solid #ff5d73';
      setTimeout(function () { t.style.outline = ''; }, 900);
      if (field === 'active') { var c = t.closest('.pcard'); if (c) c.classList.toggle('off', !t.checked); }
    });
  });

  /* ---------- product form helpers ---------- */
  $$('[data-dtype]').forEach(function (r) {
    function sync() {
      var v = ($('[data-dtype]:checked') || {}).value;
      $$('[data-show-for]').forEach(function (s) { s.hidden = s.getAttribute('data-show-for').split(' ').indexOf(v) < 0; });
    }
    r.addEventListener('change', sync); sync();
  });
  $$('[data-import-target]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var f = inp.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () { var t = $(inp.getAttribute('data-import-target')); t.value = (t.value ? t.value.trim() + '\n' : '') + rd.result.replace(/\r/g, '').trim(); t.dispatchEvent(new Event('input')); };
      rd.readAsText(f); inp.value = '';
    });
  });
  $$('textarea[data-count-lines]').forEach(function (t) {
    var out = $(t.getAttribute('data-count-lines'));
    var f = function () { var n = t.value.split(/\r?\n/).filter(function (l) { return l.trim(); }).length; out.textContent = n + ' كود'; };
    t.addEventListener('input', f); f();
  });

  /* ---------- charts ---------- */
  var ch = $('#salesChart');
  if (ch) {
    var all = JSON.parse(ch.getAttribute('data-series')), range = 30;
    var draw = function () {
      var d = all.slice(-range), W = 760, H = 230, pl = 8, pr = 8, pt = 14, pb = 26;
      var max = Math.max.apply(null, d.map(function (x) { return x.r; }).concat([1]));
      var x = function (i) { return pl + (W - pl - pr) * (d.length === 1 ? 0 : i / (d.length - 1)); };
      var y = function (v) { return pt + (H - pt - pb) * (1 - v / max); };
      var pts = d.map(function (p, i) { return x(i).toFixed(1) + ',' + y(p.r).toFixed(1); });
      var area = 'M' + x(0) + ',' + (H - pb) + ' L' + pts.join(' L') + ' L' + x(d.length - 1) + ',' + (H - pb) + ' Z';
      var grid = [0, .5, 1].map(function (g) { var yy = pt + (H - pt - pb) * g; return '<line x1="0" x2="' + W + '" y1="' + yy + '" y2="' + yy + '" stroke="rgba(120,170,255,.12)"/>'; }).join('');
      var labels = [0, Math.floor(d.length / 2), d.length - 1].map(function (i) {
        return '<text x="' + x(i) + '" y="' + (H - 6) + '" fill="#8ea3c4" font-size="11" text-anchor="middle">' + d[i].d.slice(5) + '</text>';
      }).join('');
      ch.innerHTML = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none"><defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2f8bff" stop-opacity=".45"/><stop offset="1" stop-color="#2f8bff" stop-opacity="0"/></linearGradient></defs>' +
        grid + '<path d="' + area + '" fill="url(#ga)"/><polyline points="' + pts.join(' ') + '" fill="none" stroke="#4de0ff" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>' +
        d.map(function (p, i) { return p.r > 0 ? '<circle cx="' + x(i) + '" cy="' + y(p.r) + '" r="3.2" fill="#4de0ff"><title>' + p.d + ' — $' + p.r + ' (' + p.n + ' طلب)</title></circle>' : ''; }).join('') + labels + '</svg>';
      var tot = d.reduce(function (s, p) { return s + p.r; }, 0), n = d.reduce(function (s, p) { return s + p.n; }, 0);
      $('#chartTotal').textContent = '$' + tot.toFixed(2) + ' · ' + n + ' طلب';
    };
    $$('[data-range]').forEach(function (b) {
      b.addEventListener('click', function () { range = parseInt(b.getAttribute('data-range'), 10); $$('[data-range]').forEach(function (x) { x.classList.toggle('on', x === b); }); draw(); });
    });
    draw();
  }
  $$('.donut').forEach(function (el) {
    var parts = JSON.parse(el.getAttribute('data-parts')), total = parts.reduce(function (s, p) { return s + p.n; }, 0) || 1, acc = 0, R = 15.9;
    el.innerHTML = '<svg viewBox="0 0 42 42" width="140" height="140"><circle cx="21" cy="21" r="' + R + '" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="5"/>' +
      parts.map(function (p) { var len = p.n / total * 100, s = '<circle cx="21" cy="21" r="' + R + '" fill="none" stroke="' + p.color + '" stroke-width="5" stroke-dasharray="' + len + ' ' + (100 - len) + '" stroke-dashoffset="' + (25 - acc) + '"/>'; acc += len; return s; }).join('') +
      '<text x="21" y="23.5" fill="#fff" font-size="8" font-weight="700" text-anchor="middle">' + (total === 1 && !parts.length ? 0 : total) + '</text></svg>';
  });

  /* flash auto hide */
  setTimeout(function () { $$('.flash').forEach(function (f) { f.style.transition = '.5s'; f.style.opacity = '0'; setTimeout(function () { f.remove(); }, 500); }); }, 6000);
})();
