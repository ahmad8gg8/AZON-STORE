(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var csrf = ($('meta[name="csrf-token"]') || {}).content || '';
  var loggedIn = document.body.dataset.login === '1';

  function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : t; return d.innerHTML; }
  function money(n) { return '$' + Number(n || 0).toFixed(2); }

  function toast(msg, kind) {
    var box = $('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; document.body.appendChild(box); }
    var t = document.createElement('div');
    t.className = 'toast ' + (kind || 'ok');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(function () { t.remove(); }, 4200);
  }
  $$('.toast').forEach(function (t) { setTimeout(function () { t.remove(); }, 4200); });

  function api(url, data) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify(data || {})
    }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, data: j }; }); });
  }

  /* ---------- cart + checkout drawer (everything happens in here) ---------- */
  var drawer = $('#drawer'), scrim = $('#scrim');
  var dBody = $('#drawerBody'), dFoot = $('#drawerFoot'), dTitle = $('#dTitle'), dSteps = $('#dSteps');
  var S = { view: 'cart', cart: null, poll: null, stripe: null, elements: null };

  function openDrawer() { drawer.classList.add('on'); scrim.classList.add('on'); drawer.setAttribute('aria-hidden', 'false'); }
  function closeDrawer() {
    drawer.classList.remove('on'); scrim.classList.remove('on'); drawer.setAttribute('aria-hidden', 'true');
    $('#navLinks').classList.remove('open');
  }
  $('#cartBtn').addEventListener('click', function () { openDrawer(); if (S.view !== 'track') { setView('cart'); loadCart(); } });
  $('#drawerClose').addEventListener('click', closeDrawer);
  scrim.addEventListener('click', closeDrawer);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDrawer(); });
  $('#burger').addEventListener('click', function () { $('#navLinks').classList.toggle('open'); scrim.classList.add('on'); });

  function setView(v) {
    S.view = v;
    var idx = { cart: 0, pay: 1, track: 2, quote: 2 }[v];
    dTitle.textContent = { cart: 'سلتك', pay: 'الدفع', track: 'تتبع طلبك', quote: 'تم الاستلام' }[v];
    $$('i', dSteps).forEach(function (el, i) { el.className = i < idx ? 'done' : i === idx ? 'on' : ''; });
    if (v !== 'track' && S.poll) { clearInterval(S.poll); S.poll = null; }
    drawer.dataset.view = v;
  }
  function setBadge(count) { var b = $('#cartBadge'); b.textContent = count; b.hidden = !count; }
  function busy(btn, on, label) { if (!btn) return; btn.disabled = on; if (label) btn.innerHTML = on ? '<span class="spin"></span>' : label; }

  /* ----- cart view ----- */
  function renderCart(p) {
    S.cart = p; setBadge(p.count);
    if (S.view !== 'cart') return;
    if (!p.cart.length) {
      dBody.innerHTML = '<div class="d-empty"><div class="d-empty-ic">🛒</div><p>سلتك فاضية</p></div>';
      dFoot.innerHTML = '<a href="/products" class="btn btn-ghost wide">تصفح المنتجات</a>';
      return;
    }
    dBody.innerHTML = p.cart.map(function (i) {
      return '<div class="line"><div class="line-art">' + esc((i.name || 'A').trim().charAt(0)) + '</div>' +
        '<div class="line-info"><a href="/products/' + esc(i.slug) + '">' + esc(i.name) + '</a><small>' +
        (i.is_custom_pricing ? 'تسعير مخصص' : money(i.price)) + '</small></div>' +
        (i.is_custom_pricing ? '' :
          '<div class="stepper"><button data-q="' + i.product_id + '" data-d="-1" aria-label="-">−</button><b>' + i.quantity +
          '</b><button data-q="' + i.product_id + '" data-d="1" aria-label="+">+</button></div>') +
        '<button class="icon-btn danger" data-rm="' + i.product_id + '" aria-label="حذف">×</button></div>';
    }).join('') +
      (p.coupon
        ? '<div class="coupon on"><span>🏷 ' + esc(p.coupon.code) + ' (−' + p.coupon.percent + '%)</span><button class="mini" data-coupon-rm>إزالة</button></div>'
        : '<div class="coupon"><input type="text" id="cpIn" placeholder="عندك كود خصم؟" maxlength="40"><button class="mini" data-coupon-add>تطبيق</button></div>');
    dFoot.innerHTML =
      (p.discount > 0 ? '<div class="tot sm"><span>الخصم</span><span>−' + money(p.discount) + '</span></div>' : '') +
      '<div class="tot"><span>الإجمالي</span><span>' + money(p.total) + '</span></div>' +
      '<button class="btn btn-glow wide" data-checkout>' + (p.subtotal === 0 ? 'إرسال الطلب' : 'ادفع الآن') + '</button>' +
      '<a href="/cart" class="d-link">عرض صفحة السلة</a>';
  }
  function loadCart() { return fetch('/api/cart').then(function (r) { return r.json(); }).then(renderCart); }

  /* ----- checkout start ----- */
  function startCheckout(btn) {
    if (!S.cart || !S.cart.cart.length) return;
    if (!S.cart.logged_in) {
      try { sessionStorage.setItem('azon_resume', 'checkout'); } catch (e) {}
      dBody.innerHTML = '<div class="d-empty"><div class="spin lg"></div><p>نحوّلك لتسجيل الدخول عبر ديسكورد…</p></div>';
      dFoot.innerHTML = '';
      setTimeout(function () { location.href = '/auth/discord?next=' + encodeURIComponent('/'); }, 500);
      return;
    }
    var label = btn && btn.innerHTML; busy(btn, true);
    api('/api/checkout/start', {}).then(function (res) {
      busy(btn, false, label);
      if (res.data && res.data.error === 'login_required') { location.href = '/auth/discord?next=/'; return; }
      if (!res.ok) return toast(res.data.error || 'تعذّر بدء الطلب', 'err');
      setBadge(0);
      if (res.data.quote) return renderQuote(res.data.order_id);
      if (res.data.paid) return renderTrack(res.data.order_id, true);
      renderPay(res.data);
    });
  }

  /* ----- payment view ----- */
  function loadScript(src) {
    return new Promise(function (ok, bad) {
      var el = document.createElement('script'); el.src = src; el.onload = ok; el.onerror = bad; document.head.appendChild(el);
    });
  }

  function renderPay(d) {
    setView('pay'); openDrawer();
    dBody.innerHTML =
      '<div class="pay-sum">' + d.items.map(function (i) {
        return '<div><span>' + esc(i.name) + ' <small>× ' + i.quantity + '</small></span><b>' + money(i.price * i.quantity) + '</b></div>';
      }).join('') +
      (d.discount > 0 ? '<div class="disc"><span>الخصم</span><b>−' + money(d.discount) + '</b></div>' : '') +
      '<div class="pay-total"><span>الإجمالي</span><b>' + money(d.total) + '</b></div></div>' +
      (d.stripe ? '<div class="pay-box"><div id="payEl" class="pay-el"><div class="spin lg"></div></div><div id="payErr" class="pay-err"></div></div>' : '') +
      (d.paypal ? (d.stripe ? '<div class="or"><span>أو</span></div>' : '') + '<div id="ppBox" class="pp-box"></div>' : '') +
      (!d.stripe && !d.paypal ? '<p class="empty">الدفع غير مفعّل بعد — لازم مالك المتجر يضيف مفاتيح Stripe و/أو PayPal.</p>' : '') +
      '<p class="secure">🔒 دفع مشفّر وآمن — بياناتك ما تمرّ على سيرفرنا</p>';
    dFoot.innerHTML =
      (d.stripe ? '<button class="btn btn-glow wide" id="payBtn" disabled>ادفع ' + money(d.total) + '</button>' : '') +
      '<button class="d-link" data-back>← رجوع للسلة</button>';

    if (d.stripe) mountStripe(d);
    if (d.paypal) mountPaypal(d);
  }

  function mountStripe(d) {
    var payBtn = $('#payBtn');
    Promise.all([
      window.Stripe ? 0 : loadScript('https://js.stripe.com/v3/'),
      api('/api/checkout/intent', { order_id: d.order_id })
    ]).then(function (r) {
      var res = r[1];
      if (!res.ok) { $('#payEl').innerHTML = '<p class="pay-err">' + esc(res.data.error || 'تعذّر تحميل الدفع') + '</p>'; return; }
      S.stripe = window.Stripe(d.stripe_key);
      S.elements = S.stripe.elements({
        clientSecret: res.data.client_secret, locale: 'ar',
        appearance: {
          theme: 'night',
          variables: { colorPrimary: '#2f8bff', colorBackground: '#0b1a30', colorText: '#eaf2ff', colorDanger: '#ff5d73',
            fontFamily: 'Cairo, system-ui, sans-serif', borderRadius: '12px', spacingUnit: '4px' }
        }
      });
      var el = S.elements.create('payment', { layout: { type: 'tabs' }, wallets: { applePay: 'auto', googlePay: 'auto' } });
      $('#payEl').innerHTML = '';
      el.mount('#payEl');
      el.on('ready', function () { payBtn.disabled = false; });
      payBtn.addEventListener('click', function () {
        var label = payBtn.innerHTML; busy(payBtn, true); $('#payErr').textContent = '';
        S.stripe.confirmPayment({
          elements: S.elements, redirect: 'if_required',
          confirmParams: { return_url: location.origin + '/?pay_return=' + d.order_id }
        }).then(function (out) {
          if (out.error) { busy(payBtn, false, label); $('#payErr').textContent = out.error.message || 'فشلت العملية'; return; }
          api('/api/checkout/confirm', { order_id: d.order_id, payment_intent: out.paymentIntent.id }).then(function () {
            renderTrack(d.order_id, true);
          });
        });
      });
    }).catch(function () { $('#payEl').innerHTML = '<p class="pay-err">تعذّر تحميل نموذج الدفع.</p>'; });
  }

  function mountPaypal(d) {
    var box = $('#ppBox');
    var go = function () {
      window.paypal.Buttons({
        style: { color: 'blue', shape: 'pill', height: 46, label: 'paypal' },
        createOrder: function () {
          return api('/checkout/paypal/create/' + d.order_id, {}).then(function (r) { return r.data.id; });
        },
        onApprove: function (data) {
          return api('/checkout/paypal/capture/' + d.order_id, { paypal_order_id: data.orderID }).then(function (r) {
            if (r.ok) renderTrack(d.order_id, true); else toast('تعذّر تأكيد الدفع', 'err');
          });
        },
        onError: function () { toast('حصل خطأ بـ PayPal', 'err'); }
      }).render('#ppBox');
    };
    if (window.paypal) return go();
    loadScript('https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(d.paypal_client_id) + '&currency=USD').then(go)
      .catch(function () { box.innerHTML = ''; });
  }

  /* ----- quote view ----- */
  function renderQuote(orderId) {
    setView('quote'); openDrawer();
    dBody.innerHTML = '<div class="done-card"><div class="check"><svg viewBox="0 0 52 52"><path d="M14 27l8 8 16-17"/></svg></div>' +
      '<h3>استلمنا طلبك #' + orderId + '</h3><p>هذا الطلب يحتاج تسعير مخصص، وبنتواصل معك على ديسكورد قريباً.</p></div>';
    dFoot.innerHTML = '<a href="/orders/' + orderId + '" class="btn btn-ghost wide">تفاصيل الطلب</a>';
  }

  /* ----- tracking view ----- */
  function confetti() {
    var wrap = document.createElement('div'); wrap.className = 'confetti';
    for (var i = 0; i < 36; i++) {
      var c = document.createElement('i');
      c.style.cssText = 'left:' + Math.random() * 100 + '%;background:' + ['#2f8bff', '#4de0ff', '#fff', '#1b5fd6'][i % 4] +
        ';animation-delay:' + Math.random() * .5 + 's;animation-duration:' + (1.4 + Math.random() * 1.2) + 's;--dx:' + (Math.random() * 120 - 60) + 'px';
      wrap.appendChild(c);
    }
    drawer.appendChild(wrap); setTimeout(function () { wrap.remove(); }, 3200);
  }

  function renderTrack(orderId, fresh) {
    setView('track'); openDrawer(); setBadge(0);
    dBody.innerHTML = '<div class="done-card"><div class="check"><svg viewBox="0 0 52 52"><path d="M14 27l8 8 16-17"/></svg></div>' +
      '<h3>تم الدفع بنجاح</h3><p>طلب #' + orderId + '</p></div>' +
      '<ol class="track" id="track">' +
      '<li data-s="paid"><i></i><div><b>تم استلام الدفع</b><small>دفعتك وصلتنا</small></div></li>' +
      '<li data-s="proc"><i></i><div><b>قيد التجهيز</b><small>نجهّز طلبك الآن</small></div></li>' +
      '<li data-s="done"><i></i><div><b>تم التسليم</b><small>يوصلك على ديسكورد</small></div></li></ol>' +
      '<div id="codes"></div><div id="dnote"></div>';
    dFoot.innerHTML = '<a href="/orders/' + orderId + '" class="btn btn-ghost wide">تفاصيل الطلب</a><button class="d-link" data-close>متابعة التسوق</button>';
    if (fresh) confetti();
    var tick = function () {
      fetch('/api/orders/' + orderId + '/status').then(function (r) { return r.json(); }).then(function (o) {
        var paid = o.status === 'paid' || o.status === 'delivered', done = o.status === 'delivered';
        var li = $$('#track li');
        if (!li.length) return;
        li[0].className = paid ? 'done' : 'on';
        li[1].className = done ? 'done' : paid ? 'on' : '';
        li[2].className = done ? 'done' : '';
        if (done) {
          if (S.poll) { clearInterval(S.poll); S.poll = null; }
          if (o.note) { $('#dnote').innerHTML = '<div class="line-note">' + esc(o.note) + '</div>'; }
          if (o.codes && o.codes.length) {
            $('#codes').innerHTML = '<h4>أكوادك</h4>' + o.codes.map(function (c) {
              return '<button class="code" data-copy="' + esc(c) + '"><span>' + esc(c) + '</span><em>نسخ</em></button>';
            }).join('');
          }
        }
      }).catch(function () {});
    };
    tick(); S.poll = setInterval(tick, 3000);
    setTimeout(function () { if (S.poll) { clearInterval(S.poll); S.poll = null; } }, 600000);
  }

  /* ----- delegated clicks ----- */
  document.addEventListener('click', function (e) {
    var t = e.target;
    var add = t.closest('[data-add]');
    if (add) {
      e.preventDefault();
      api('/api/cart/add', { product_id: add.dataset.add }).then(function (res) {
        if (!res.ok) return toast(res.data.error || 'تعذّرت الإضافة', 'err');
        setView('cart'); renderCart(res.data); toast('تمت الإضافة للسلة'); openDrawer();
      });
      return;
    }
    var q = t.closest('[data-q]');
    if (q) {
      var it = S.cart.cart.filter(function (i) { return String(i.product_id) === q.dataset.q; })[0];
      var n = it.quantity + parseInt(q.dataset.d, 10);
      if (n < 1) return;
      api('/api/cart/update', { product_id: q.dataset.q, quantity: n }).then(function (res) { renderCart(res.data); });
      return;
    }
    var rm = t.closest('[data-rm]');
    if (rm) { api('/api/cart/remove', { product_id: rm.dataset.rm }).then(function (res) { renderCart(res.data); }); return; }
    if (t.closest('[data-coupon-add]')) {
      api('/api/cart/coupon', { code: $('#cpIn').value }).then(function (res) {
        if (!res.ok) return toast(res.data.error, 'err');
        renderCart(res.data); toast('تم تفعيل الكود');
      });
      return;
    }
    if (t.closest('[data-coupon-rm]')) { api('/api/cart/coupon', { code: '' }).then(function (res) { renderCart(res.data); }); return; }
    var co = t.closest('[data-checkout]');
    if (co) {
      e.preventDefault();
      if (!drawer.classList.contains('on')) { openDrawer(); setView('cart'); loadCart().then(function () { startCheckout(null); }); }
      else startCheckout(co);
      return;
    }
    if (t.closest('[data-back]')) { setView('cart'); loadCart(); return; }
    if (t.closest('[data-close]')) { closeDrawer(); return; }
    var cp = t.closest('[data-copy]');
    if (cp) {
      try { navigator.clipboard.writeText(cp.dataset.copy); } catch (er) {}
      var em = $('em', cp); em.textContent = 'تم ✓'; setTimeout(function () { em.textContent = 'نسخ'; }, 1500);
      return;
    }
    var fav = t.closest('[data-fav]');
    if (fav) {
      e.preventDefault();
      if (!loggedIn) { location.href = '/auth/discord?next=' + encodeURIComponent(location.pathname); return; }
      api('/wishlist/toggle', { product_id: fav.dataset.fav }).then(function (res) {
        fav.classList.toggle('on', !!res.data.added);
        toast(res.data.added ? 'أُضيف للمفضلة' : 'أُزيل من المفضلة');
      });
    }
  });

  /* ----- boot: resume after login / 3DS redirect / deep links ----- */
  (function boot() {
    var qs = new URLSearchParams(location.search);
    var resume = null;
    try { resume = sessionStorage.getItem('azon_resume'); sessionStorage.removeItem('azon_resume'); } catch (e) {}
    var clean = function () { history.replaceState(null, '', location.pathname + location.hash); };

    if (qs.get('pay_return') && qs.get('payment_intent')) {
      var oid = qs.get('pay_return'); clean();
      api('/api/checkout/confirm', { order_id: oid, payment_intent: qs.get('payment_intent') }).then(function () { renderTrack(oid, true); });
      return;
    }
    if (qs.get('pay') && loggedIn) {
      var id = qs.get('pay'); clean();
      fetch('/api/checkout/order/' + id).then(function (r) { return r.json(); }).then(function (d) {
        if (d.items) renderPay(d); else if (d.order_id) renderTrack(d.order_id, false);
      });
      return;
    }
    if ((qs.get('checkout') || resume === 'checkout') && loggedIn) {
      clean(); openDrawer(); setView('cart');
      loadCart().then(function () { if (S.cart.cart.length) startCheckout(null); });
      return;
    }
    if (qs.get('checkout')) { clean(); openDrawer(); setView('cart'); loadCart(); }
  })();

  /* ---------- 3D tilt + spotlight ---------- */
  if (matchMedia('(hover:hover)').matches) {
    $$('[data-tilt]').forEach(function (el) {
      el.addEventListener('mousemove', function (e) {
        var b = el.getBoundingClientRect();
        var x = (e.clientX - b.left) / b.width - .5, y = (e.clientY - b.top) / b.height - .5;
        el.style.transform = 'perspective(800px) rotateY(' + (x * 10) + 'deg) rotateX(' + (-y * 10) + 'deg) translateZ(0)';
      });
      el.addEventListener('mouseleave', function () { el.style.transform = ''; });
    });
  }

  /* ---------- reveal + counters ---------- */
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      en.target.classList.add('in'); io.unobserve(en.target);
      var n = en.target.querySelector && $$('[data-count]', en.target);
      (en.target.hasAttribute('data-count') ? [en.target] : n || []).forEach(count);
    });
  }, { threshold: .12 });
  function count(el) {
    var to = parseInt(el.dataset.count, 10) || 0, t0 = performance.now();
    (function step(t) {
      var k = Math.min(1, (t - t0) / 1100);
      el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3)));
      if (k < 1) requestAnimationFrame(step);
    })(t0);
  }
  $$('.block, .card, .step, .review, .index-row').forEach(function (el, i) {
    el.setAttribute('data-reveal', ''); el.style.transitionDelay = Math.min(i % 6, 5) * 60 + 'ms'; io.observe(el);
  });
})();
