// Usage: node scripts/reset-2fa.js <admin-username>
// Removes two-factor auth from an admin account (e.g. if the phone was lost).
const { getDb, initDb } = require("../db");
initDb();
const name = process.argv[2];
if (!name) { console.log("Usage: node scripts/reset-2fa.js <admin-username>"); process.exit(1); }
const r = getDb().prepare("UPDATE admin_users SET totp_secret = NULL WHERE username = ?").run(name);
console.log(r.changes ? `2FA removed for "${name}".` : `No admin named "${name}".`);
